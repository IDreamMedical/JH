﻿using System;
using System.Printing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace PrintQueuesExample
{
  public partial class Window1 : Window
  {
    PrintQueueCollection _Printers;

    public Window1()
    {
      _Printers = new PrintServer().GetPrintQueues(new[] { 
        EnumeratedPrintQueueTypes.Local, EnumeratedPrintQueueTypes.Connections});

      foreach (var queue in _Printers)
      {
        Console.WriteLine(queue.Name);
        var capabilities = queue.GetPrintCapabilities();
        foreach (var size in capabilities.PageMediaSizeCapability)
        { Console.WriteLine(size.ToString()); }
        Console.WriteLine();
      }

      InitializeComponent();
    }

    public PrintQueueCollection Printers
    { get { return _Printers; } }

    private void PrintTestPageClick(object sender, RoutedEventArgs e)
    {
      var queue = _PrinterList.SelectedItem as PrintQueue;
      if (queue == null)
      {
        MessageBox.Show("Please select a printer.");
        return;
      }

      var size = _SizeList.SelectedItem as PageMediaSize;
      if (size == null)
      {
        MessageBox.Show("Please select a page size.");
        return;
      }

      queue.UserPrintTicket.PageMediaSize = size;
      queue.UserPrintTicket.PageOrientation = _PortraitRadio.IsChecked == true ? 
        PageOrientation.Portrait : PageOrientation.Landscape;

      var canvas = (Canvas)Resources["MyPrintingExample"];
      canvas.Measure(new Size(size.Width.Value, size.Height.Value));
      canvas.Arrange(new Rect(0, 0, canvas.DesiredSize.Width, 
          canvas.DesiredSize.Height));

      var writer = PrintQueue.CreateXpsDocumentWriter(queue);
      writer.Write(canvas);
    }

  }

  public class PrintQueueToPageSizesConverter : IValueConverter
  {
    public object Convert(object value, Type targetType,
      object parameter, System.Globalization.CultureInfo culture)
    {
      return value == null ? null :
        ((PrintQueue)value).GetPrintCapabilities().PageMediaSizeCapability;
    }

    public object ConvertBack(object value, Type targetType, 
      object parameter, System.Globalization.CultureInfo culture)
    { throw new NotImplementedException(); }
  }
}
