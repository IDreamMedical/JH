﻿using System.Windows;
using System.Windows.Controls;

namespace PaginatorExample
{
  public partial class Window1 : Window
  {
    public Window1()
    { InitializeComponent(); }

    private void PrintClick(object sender, RoutedEventArgs e)
    {
      int rows = 0;
      if(!int.TryParse(NumRows.Text, out rows) || rows < 0)
      {
        MessageBox.Show("Not a valid number of rows.");
        return;        
      }
      
      var printDialog = new PrintDialog();
      if (printDialog.ShowDialog() == true)
      {
        var paginator = new RandomTabularPaginator(rows,
          new Size(printDialog.PrintableAreaWidth, printDialog.PrintableAreaHeight));

        printDialog.PrintDocument(paginator, "My Random Data Table");
      }
    }
  }
}
